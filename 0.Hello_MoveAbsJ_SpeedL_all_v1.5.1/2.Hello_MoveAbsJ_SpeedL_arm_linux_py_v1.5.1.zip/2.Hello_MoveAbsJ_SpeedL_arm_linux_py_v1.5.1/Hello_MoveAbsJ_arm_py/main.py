import rpc
import random
import time


# 初始化命令列表
init_cmds = [
    "{Clear}",
    "{Disable}",
    "{Mode}",
    "{SetMaxToq}",
    "{Recover}",
    "{SetRate}",
    "{Enable}",
    "{Var --clear}",
    "{Recover}",
    "{Var --type=jointtarget --name=j0 --value={0,0,0,0,0,0,0,0,0,0}}",
    "{Var --type=jointtarget --name=j1 --value={0.1,-1.5,0,0,0,0,0,0,0,0}}",
    "{Var --type=jointtarget --name=j2 --value={0.2,0,0,0,0,0,0,0,0,0}}",
    "{Var --type=jointtarget --name=j3 --value={-0.1,0,0,0,0,0,0,0,0,0}}",
    "{Var --type=jointtarget --name=j4 --value={-0.2,0,0,0,0,0,0,0,0,0}}"
]

# 运动指令列表
motion_cmds = [
    "{MoveAbsJ --jointtarget_var=j0}",
    "{MoveAbsJ --jointtarget_var=j1}"
]

motion_speedL_cmds = [
    "{SpeedL --vel={0.01,0,0,0,0,0} --last_count=1000}",
    "{SpeedL --vel={-0.01,0,0,0,0,0} --last_count=1000}",
    "{SpeedL --vel={0.01,0,0,0,0,0} --last_count=1000}",
    "{SpeedL --vel={-0.01,0,0,0,0,0} --last_count=1000}",
    "{Stop}",
    "{Start}",
]

# 用户自定义指令列表
your_cmds = [
    # 添加你的指令
]

def main():
    """主函数"""
    # 创建客户端
    print("Connecting...")
    client = rpc.CPPClient("192.168.2.100", 5868)
    print("Connected!")
    
    # 发送初始化指令
    send_rpcsy(client, init_cmds, 500, 0.1)  # 同步rpc (client, 指令, 超时时间ms, 休眠时间s)
    
    # 主循环发送运动指令
    while True:
        # send_rpcsy(client, motion_cmds, 50000, 0.01)
        send_rpc_async(client, motion_speedL_cmds, 10000, 0.5)  # 异步rpc




def send_rpcsy(client, cmd_list, timeout_ms, sleep_time_s):
    """
    同步RPC发送函数
    
    Args:
        client: RPC客户端
        cmd_list: 指令列表
        timeout_ms: 超时时间(毫秒)
        sleep_time_s: 指令间休眠时间(秒)
    """
    for cmd in cmd_list:
        # 生成随机序列号
        random_seq = random.randint(1, 10000)
        
        # 创建消息
        msg = rpc.Msg(cmd)
        msg.setMsgID(10001)
        msg.setMsgSeqID(random_seq)
        
        # 发送并等待响应
        status, resp_list = client.CallAwait(msg, timeout_ms)
        
        if status == 0:
            print("*************Sync***************")
            print(f"model size: {len(resp_list)}")
            for r in resp_list:
                print(f"subcmd_index: {r.index}")
                print(f"return_code: {r.code}")
                print(f"return_message: {r.message}")
            print("********************************")
        else:
            print("!!!!!!!!!!!!!!!!!!Sync!!!!!!!!!!!!!!")
            print(f"Failed to execute command '{cmd}'. Status: {status}")
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            # 可以添加自动清理错误的代码
            # client.ClearErr()
        
        print("over!!!")
        print("****************************")
        time.sleep(sleep_time_s)  # 休眠


def send_rpc_async(client, cmd_list, timeout_ms, wait_time_s):
    """
    异步RPC发送函数
    
    Args:
        client: RPC客户端
        cmd_list: 指令列表
        timeout_ms: 超时时间(毫秒)
        wait_time_s: 指令间等待时间(秒)
    """
    def callback(status, resp_list):
        print("**************Async**************")
        if status < 0:
            print(f"Async request failed. Status: {status}, timeout!")
        else:
            print(f"model size: {len(resp_list)}")
            for r in resp_list:
                print(f"subcmd_index: {r.index}")
                print(f"return_code: {r.code}")
                print(f"return_message: {r.message}")
        print("*********************************")
    
    for cmd in cmd_list:
        # 生成随机序列号
        random_seq = random.randint(1, 10000)
        
        # 创建消息
        msg = rpc.Msg(cmd)
        msg.setMsgID(10001)
        msg.setMsgSeqID(random_seq)
        
        # 异步调用
        success = client.CallAsync(msg, timeout_ms, callback)
        
        if not success:
            print(f"Failed to send async command: {cmd}")
        
        # 等待一段时间再发送下一条指令
        time.sleep(wait_time_s)
    
    print("All commands sent asynchronously")



# 程序入口
if __name__ == "__main__":
    main()