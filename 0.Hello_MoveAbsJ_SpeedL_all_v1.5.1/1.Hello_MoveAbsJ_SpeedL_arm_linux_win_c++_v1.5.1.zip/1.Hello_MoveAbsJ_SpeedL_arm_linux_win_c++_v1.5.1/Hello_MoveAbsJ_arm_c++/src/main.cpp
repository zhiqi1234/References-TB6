﻿#include "cpp_rpc.hpp"
#include <iostream>
#include <stdlib.h>
#include <time.h> 
#include"rpc_client.h"

int main() {

    std::vector<std::string> init_cmds = {
    "{Clear}",
    "{Disable}",
    "{Mode}",
    "{SetMaxToq}",
    "{Recover}",
    "{SetRate}",
    "{Enable}",
    "{Var --clear}",
    "{Recover}",
    "{Var --type=jointtarget --name=j0 --value={0,0,0,0,0,0,0,0,0,0}}",
    "{Var --type=jointtarget --name=j1 --value={0.1,-1.5,0,0,0,0,0,0,0,0}}",
    "{Var --type=jointtarget --name=j2 --value={0.2,0,0,0,0,0,0,0,0,0}}",
    "{Var --type=jointtarget --name=j3 --value={-0.1,0,0,0,0,0,0,0,0,0}}",
    "{Var --type=jointtarget --name=j4 --value={-0.2,0,0,0,0,0,0,0,0,0}}"
    };

    std::vector<std::string> motion_cmds = {
    "{MoveAbsJ --jointtarget_var=j0}",   //"{MoveAbsJ --jointtarget_var=j0||NotRunExecute}"   //Single-arm instructions when both arms are available.
    "{MoveAbsJ --jointtarget_var=j1}",
    "{MoveAbsJ --jointtarget_var=j2}"
    };

    std::vector<std::string> motion_speedL_cmds = {
    "{SpeedL --vel={0.01,0,0,0,0,0} --last_count=1000}",
    "{SpeedL --vel={-0.01,0,0,0,0,0} --last_count=1000}",
    "{SpeedL --vel={0.01,0,0,0,0,0} --last_count=1000}",
    "{SpeedL --vel={-0.01,0,0,0,0,0} --last_count=1000}",
    "{Stop}",
    "{Start}",
    };
    
    std::vector<std::string> your_cmds = {

        //add your cmds

    };

    // Connecting
    std::cout << "Connecting: " << std::endl;
    cpp_rpc::CPPClient client("192.168.2.33", 5868);
    std::cout << "Connected: " << std::endl;

    //init
    send_rpcsy(client, init_cmds, 500, 100);  //Synchronous RPC (connect client, command, timeout, sleep time)

    // main motion
    while (1) {

        send_rpcsy(client, motion_cmds, 50000, 1000);
        //send_rpcAsy(client, motion_speedL_cmds,10000,500);  //Asynchronous RPC (connect client, command, timeout, sleep time)
    }

    return 0;
}

/***************************************************** */
/*********                                   ******** */
/*********    Communication Encapsulation    ******** */
/*********                                  ******** */
/*************************************************** */


void delay_ms(unsigned int milliseconds);

/*  Synchronous RPC  char* argv[] */
void send_rpcsy(cpp_rpc::CPPClient& client, const std::vector<std::string>& cmd_cmd, int outim_num, int sleep_num) {
    for (const auto& cmd : cmd_cmd) {

        char* fake_argv[] = { const_cast<char*>("dummy"), const_cast<char*>(cmd.c_str()) };

        srand(time(0));
        int i = rand();

        std::string msg(fake_argv[1]);

        core::Msg sync_msg(msg);
        sync_msg.setMsgID(10001);
        sync_msg.setMsgSeqID(i);

        auto res = client.CallAwait<RespDemo>(sync_msg, outim_num);
        if (0 == res.first) {
            std::cout << "*************Sync***************" << std::endl;
            std::cout << "model size:" << res.second.size() << std::endl;
            for (const auto& r : res.second) {
                std::cout << "subcmd_index:" << r.subcmd_index << std::endl;
                std::cout << "return_code:" << r.return_code << std::endl;
                std::cout << "return_message:" << r.return_message << std::endl;
            }
            std::cout << "****************************" << std::endl;
        }
        else {
            std::cout << "Synchronous request failed! Ensure that the timeout is greater than the command execution time! Error code: " << res.first << std::endl;
            
            // client.ClearErr();
        }

        std::cout << "over!!!" << std::endl;
        std::cout << "****************************" << std::endl;
        delay_ms(sleep_num);
    }

}

/*  Asynchronous RPC  */
void send_rpcAsy(cpp_rpc::CPPClient& client, const std::vector<std::string>& cmd_cmd, int outim_num, int wait_num) {
    for (const auto& cmd : cmd_cmd) {

        char* fake_argv[] = { const_cast<char*>("dummy"), const_cast<char*>(cmd.c_str()) };

        srand(time(0));
        int i = rand();

        std::string msg(fake_argv[1]);

        core::Msg message(msg);
        client.CallAsync<RespDemo>(message, outim_num, [&](int ret, std::vector<RespDemo> res) {

            std::cout << "**************Async**************" << std::endl;
            if (ret < 0) {
                std::cout << "Async request failed. ret:" << ret << " " << "out time !" << std::endl;
            }

            std::cout << "model size:" << res.size() << std::endl;
            for (const auto& r : res) {
                std::cout << "subcmd_index:" << r.subcmd_index << std::endl;
                std::cout << "return_code:" << r.return_code << std::endl;
                std::cout << "return_message:" << r.return_message << std::endl;
            }
            std::cout << "*********************************" << std::endl;
            });

        core::Msg sync_msg(msg);
        sync_msg.setMsgID(10001);
        sync_msg.setMsgSeqID(i);

        // std::this_thread::sleep_for(std::chrono::seconds(wait_num)); // Waiting for the asynchronous operation to complete.
        delay_ms(wait_num);  // Waiting for the asynchronous operation to complete.
    }
}





#ifdef _WIN32
#include <windows.h>
void delay_ms(unsigned int ms) { Sleep(ms); }
#else
#include <unistd.h>
void delay_ms(unsigned int ms) { usleep(ms * 1000); }
#endif